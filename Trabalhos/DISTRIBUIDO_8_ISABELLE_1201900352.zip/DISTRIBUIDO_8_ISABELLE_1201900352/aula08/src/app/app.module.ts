import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp({
      apiKey: "AIzaSyAaOWrsF1latHWYH46eovXfBh8HGUOiSGA",
      authDomain: "aula08-68b76.firebaseapp.com",
      projectId: "aula08-68b76",
      storageBucket: "aula08-68b76.appspot.com",
      messagingSenderId: "948749691728",
      appId: "1:948749691728:web:2a8eb6cf16e6ffaee0da55"
    }),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

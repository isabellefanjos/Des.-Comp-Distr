package com.example.oauth2aula7OpeNet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2aula7OpeNetApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.oauth2aula7OpeNet;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Controller {
	
	@GetMapping("/")
	public String olamundo() {
		return "Seja bem vindo ao exercicio sobre implementação de Oauth2";
	}

	@GetMapping("/restricted")
	public String restricted() {
		return "Se você está vendo essa mensagem, você está logado.";
	}
}

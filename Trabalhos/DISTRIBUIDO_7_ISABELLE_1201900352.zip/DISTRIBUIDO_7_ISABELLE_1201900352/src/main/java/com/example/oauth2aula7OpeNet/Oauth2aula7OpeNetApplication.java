package com.example.oauth2aula7OpeNet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2aula7OpeNetApplication {

	public static void main(String[] args) {
		SpringApplication.run(Oauth2aula7OpeNetApplication.class, args);
	}

}
